<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/tugas_web_p8_42/public/dataDiri', 'Home::DataDiri');
$routes->get('/tugas_web_p8_42/public/welcome_message', 'Home::index');
